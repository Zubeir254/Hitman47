<p align="center">
<img src="https://ibb.co/MZM1s0d/>
</p>

## ***♥️Hitman47♥️***
> This Script WhatsApp Bot Using Library Baileys & Script is free for everyone, not for Sale!
> ***Note: it's a modified version of [chisato-WhatsAp](https://github.com/AliAryanTech/Chisato-WhatsApp)***
</br>

<a 
href="https://github.com/DkHitman/"><img title="Author" src="https://img.shields.io/badge/Author-Hitman47-blue.svg?color=54aeff&style=for-the-badge&logo=github" /></a>  
<a href="https://github.com/Dkhitman3/Hitman47"><img title="Stars" src="https://img.shields.io/github/stars/Dkhitman3/Hitman47?color=54aeff&style=flat-square" /></a>
<a href="https://github.com/Dkhitman3/Hitman47/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Dkhitman3/Hitman47?color=54aeff&style=flat-square" /></a>
<a href="https://github.com/Dkhitman3/Bot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Dkhitman3/Bot?label=watchers&color=54aeff&style=flat-square" /></a> <br>

1. **Fork the repo**
    <br>
<a href='https://github.com/Dkhitman3/Hitman47/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

---

### Deployment Methods ♥️
[![Deploy with Heroku](https://www.herokucdn.com/deploy/button.svg "Deploy with Heroku")](https://heroku.com/deploy?template=https://github.com/Dkhitman3/Hitman47/blob/master/ "Deploy with Heroku")
[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/apps/deploy?type=docker&image=quay.io/toshi-san001/koyeb-auto-install:main&env%5BPORT%5D=8000&env%5BPREFIX%5D&&env%5BMONGODB%5D&&env%MODS%5D&name=Hitman47)
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template/3j9GNw?referralCode=TE7efK)

**here is the video how to deploy**

[Youtube 🎥](https://youtu.be/K7KycxbCTOs?feature=shared)

### Deployment Guide🏮
- [Self Hosting Guide](https://github.com/Dkhitman3/Hitman47/tree/master?tab=readme-ov-file/blob/master/Self-Hosting-Guide.md)
- [Heroku Hosting Guide](https://github.com/Dkhitman3/Hitman47/tree/master?tab=readme-ov-file/blob/master/Heroku-Hosting-Guide.md)

### Preview Info🧧
- Fully Modular Design </br>
- Written in [TypeScript](https://www.typescriptlang.org/)
- Built with [Baileys](https://github.com/adiwajshing/baileys) (A Lightweight full-featured WhatsApp Library)
- Powered by [ExpressJs](https://expressjs.com/) </br>
- Database handled via [MongoDB](https://www.mongodb.com/) </br>
- Self Auth restoration </br>

### Contribution♥️
- Feel free to open issues regarding any problems or if you have any feature requests 
- Make sure to follow the ESLint Rules while editing the code and run `yarn format` before opening Pull request 

--- 

## License✡️

> Hitman47 is free and open-source software licensed under the [GNU Affero General Public License v3.0](https://github.com/Dkhitman3/Hitman47/tree/master?tab=readme-ov-file/blob/master/LICENSE)

## Support 🧧

<a href="https://chat.whatsapp.com/IE4TnhkOjjyEf53aJMTfwW">
  <img src="https://img.shields.io/badge/Support_Group-0a0a0a?style=for-the-badge&logo=whatsapp&logoColor=white">
</a>

</br>

## 🎗Help
Please give this repo a ⭐ if it helped you.

## ✍︎ Hitman47 ♥️

*This is a lovely project by Hitman47 🌹. if you have a problem with this project go fuck yourself. After forking don't do any change. If you wanna do any changes click the following Whatsapp icons and join our groups and contact an Owner*
 
HOW TO REACH THE OWNER? 👇👇👇
   <a href="https://wa.me/+27844132352?text=Hi%20I%20Am%20From%20GitHub%20☺️">
    <img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>&nbsp;&nbsp;
   <a

## Thanks To♥️
* [`Shinei | Whatshell`](https://github.com/LuckyYam/)
* [`@AliAryanTech@`](https://github.com/AliAryanTech/Chisato-WhatsApp)

- 🌱 I’m currently learning **TS Language,B##**

   🧧**I'm mot a developer**🧧

**- 📫 easy to deploy this bot just tag deploy to Heroku that's all** 

- ⚡ Fun fact **I Think I'm Funny.**
- 
